#need to check if en passant threatens king


import pygame
import copy

memory=[]

ram=[]
table={1:'W',-1:'B'}
turn=1

board=[['.','.','.','.','.','.','.','.'],['.','.','.','.','.','.','.','.'],['.','.','.','.','.','.','.','.'],['.','.','.','.','.','.','.','.'],['.','.','.','.','.','.','.','.'],['.','.','.','.','.','.','.','.'],['.','.','.','.','.','.','.','.'],['.','.','.','.','.','.','.','.']]

class piece:

    def __init__(self, name, type, team, image, virgin=True):

        self.name=name
        self.type=type
        self.team=team
        self.image=image
        self.virgin=virgin

    def __repr__(self):
        return self.name
    
Bpawn=piece('Bp', 'pawn', 'B', 'black pawn.png')
Brook=piece('Br', 'rook', 'B', 'black rook.png')
Bbishop=piece('Bb', 'bishop', 'B', 'black bishop.png')
Bknight=piece('Bk', 'knight', 'B', 'black knight.png')
Bqueen=piece('Bq', 'queen', 'B', 'black queen.png')
Bking=piece('BK', 'king', 'B', 'black king.png')
Wpawn=piece('Wp', 'pawn', 'W', 'white pawn.png')
Wrook=piece('Wr', 'rook', 'W', 'white rook.png')
Wbishop=piece('Wb', 'bishop', 'W', 'white bishop.png')
Wknight=piece('Wk', 'knight', 'W', 'white knight.png')
Wqueen=piece('Wq', 'queen', 'W', 'white queen.png')
Wking=piece('WK', 'king', 'W', 'white king.png')

empty=piece('.', '', '', '')


def board_reset():

    for n in range(8):
        board[1][n]=Bpawn
        board[6][n]=Wpawn
        for m in range(2,6):
            board[m][n]=empty

    row1=board[0]
    row1[0]=Brook
    row1[7]=Brook
    row1[1]=Bknight
    row1[6]=Bknight
    row1[2]=Bbishop
    row1[5]=Bbishop
    row1[3]=Bqueen
    row1[4]=Bking
    
    row8=board[7]
    row8[0]=Wrook
    row8[7]=Wrook
    row8[1]=Wknight
    row8[6]=Wknight
    row8[2]=Wbishop
    row8[5]=Wbishop
    row8[3]=Wqueen
    row8[4]=Wking
   
def round_switch():
    new=[]
    for row in board:
        row.reverse()
        new.append(row)
    new.reverse()
    return new

def pawn_moves(y,x):
    team=board[y][x].team
    available=[]

    if board[y][x].name=='Wp':
        if y-1>=0:
            if board[y-1][x].team=='':
                available.append([y-1,x])
        if y-1>=0 and x-1>=0:
            if board[y-1][x-1].team!=team and board[y-1][x-1].team!='':
                available.append([y-1,x-1])
        if y-1>=0 and x+1<8:
            if board[y-1][x+1].team!=team and board[y-1][x+1].team!='':
                available.append([y-1,x+1])
        if y==6 and board[5][x].team=='' and board[4][x].team=='':
            available.append([4,x])

    else:
        if y+1<8:
            if board[y+1][x].team=='':
                available.append([y+1,x])
        if y+1<8 and x-1>=0:
            if board[y+1][x-1].team!=team and board[y+1][x-1].team!='':
                available.append([y+1,x-1])
        if y+1<8 and x+1<8:
            if board[y+1][x+1].team!=team and board[y+1][x+1].team!='':
                available.append([y+1,x+1])
        if y==1 and board[2][x].team=='' and board[3][x].team=='':
            available.append([3,x])

    return available

def knight_moves(y,x):
    team=board[y][x].team
    available=[]
    if y-2>=0 and x-1>=0:
        if board[y-2][x-1].team!=team:
            available.append([y-2,x-1])
    if y-2>=0 and x+1<8:
        if board[y-2][x+1].team!=team:
            available.append([y-2,x+1])
    if y+1<8 and x+2<8:
        if board[y+1][x+2].team!=team:
            available.append([y+1,x+2])
    if y-1>=0 and x+2<8:
        if board[y-1][x+2].team!=team:
            available.append([y-1,x+2])
    if y+2<8 and x+1<8:
        if board[y+2][x+1].team!=team:
            available.append([y+2,x+1])
    if y+2<8 and x-1>=0:
        if board[y+2][x-1].team!=team:
            available.append([y+2,x-1])
    if y+1<8 and x-2>=0:
        if board[y+1][x-2].team!=team:
            available.append([y+1,x-2])
    if y-1>=0 and x-2>=0:
        if board[y-1][x-2].team!=team:
            available.append([y-1,x-2])

    return available
        
def rook_moves(y,x):
    team=board[y][x].team
    available=[]
    for n in range(1,9):
        if y+n<8:
            if board[y+n][x].team!=team:
                available.append([y+n,x])
                if board[y+n][x].team!='':
                    break
            else:
                break
    for n in range(1,9):
        if y-n>=0:
            if board[y-n][x].team!=team:
                available.append([y-n,x])
                if board[y-n][x].team!='':
                    break
            else:
                break
    for n in range(1,9):
        if x-n>=0:
            if board[y][x-n].team!=team:
                available.append([y,x-n])
                if board[y][x-n].team!='':
                    break
            else:
                break
    for n in range(1,9):
        if x+n<8:
            if board[y][x+n].team!=team:
                available.append([y,x+n])
                if board[y][x+n].team!='':
                    break
            else:
                break

    return available

def bishop_moves(y,x):
    team=board[y][x].team
    available=[]
    for n in range(1,9):
        if x+n<8 and y+n<8:
            if board[y+n][x+n].team!=team:
                available.append([y+n,x+n])
                if board[y+n][x+n].team!='':
                    break
            else:
                break
    for n in range(1,9):
        if x+n<8 and y-n>=0:
            if board[y-n][x+n].team!=team:
                available.append([y-n,x+n])
                if board[y-n][x+n].team!='':
                    break
            else:
                break
    for n in range(1,9):
        if x-n>=0 and y-n>=0:
            if board[y-n][x-n].team!=team:
                available.append([y-n,x-n])
                if board[y-n][x-n].team!='':
                    break
            else:
                break
    for n in range(1,9):
        if x-n>=0 and y+n<8:
            if board[y+n][x-n].team!=team:
                available.append([y+n,x-n])
                if board[y+n][x-n].team!='':
                    break
            else:
                break

    return available

def king_moves(y,x):
    team=board[y][x].team
    available=[]
    if x+1<8:
        if board[y][x+1].team!=team:
            available.append([y,x+1])
    if y+1<8:
        if board[y+1][x].team!=team:
            available.append([y+1,x])
    if x+1<8 and y+1<8:
        if board[y+1][x+1].team!=team:
            available.append([y+1,x+1])
    if x-1>=0 and y+1<8:
        if board[y+1][x-1].team!=team:
            available.append([y+1,x-1])
    if x-1>=0 and y-1>=0:
        if board[y-1][x-1].team!=team:
            available.append([y-1,x-1])   
    if x+1<8 and y-1>=0:
        if board[y-1][x+1].team!=team:
            available.append([y-1,x+1])
    if x-1>=0:
        if board[y][x-1].team!=team:
            available.append([y,x-1])
    if y-1>=0:
        if board[y-1][x].team!=team:
            available.append([y-1,x])
    
    return available


def moves(y,x):
    A=[]
    if board[y][x].type=='pawn':
        A=pawn_moves(y,x)
    if board[y][x].type=='knight':
        A=knight_moves(y,x)
    if board[y][x].type=='rook':
        A=rook_moves(y,x)
    if board[y][x].type=='bishop':
        A=bishop_moves(y,x)
    if board[y][x].type=='queen':
        bishop=bishop_moves(y,x)
        rook=rook_moves(y,x)
        A=bishop+rook
    if board[y][x].type=='king':
        A=king_moves(y,x)

    return A

def pawn_to_queen():
    for x in range(8):
        if board[0][x].name=='Wp':
            board[0][x]=Wqueen
    for x in range(8):
        if board[7][x].name=='Bp':
            board[7][x]=Bqueen

def check_castling():
    coords=[]
    if board[picky][pickx].type=='king' and board[picky][pickx].virgin:
        if board[picky][5].type=='' and board[picky][6].type=='':
            if board[picky][7].type=='rook' and board[picky][7].virgin:
                if [picky,5] not in get_threat(opp) and [picky,6] not in get_threat(opp):
                    coords.append([picky,7])
        if board[picky][3].type=='' and board[picky][2].type=='' and board[picky][1].type=='':
            if board[picky][0].type=='rook' and board[picky][0].virgin:
                if [picky,3] not in get_threat(opp) and [picky,2] not in get_threat(opp) and [picky,1] not in get_threat(opp):
                    coords.append([picky,0]) 
    return coords
    
def check_en_passant():
    if board[newy][newx].type=='pawn':
        if abs(newy-y)==2:
            if x-1>=0:
                if board[newy][newx-1].team==table[turn*-1] and board[newy][newx-1].type=='pawn':
                    return True
            if x+1<8:
                if board[newy][newx+1].team==table[turn*-1] and board[newy][newx+1].type=='pawn':
                    return True
    return False


def draw_menu():
    screen.blit(see_through, (0,0))
    menu_BG=(0,0,0,100)
    pygame.draw.rect(see_through, menu_BG, [0,0,800,800])

#def draw_toggle():

def print_board():
    table={1:'white',-1:'grey'}
    n=-1
    width=screen.get_width()
    height=screen.get_height()
    mouse=get_mouse()
    
    
    for x in range(8):
        n*=-1
        for y in range(8):
            
            if x*width/8 <= mouse[0] <= (x+1)*width/8 and y*height/8 <= mouse[1] <= (y+1)*height/8:
                if pick:
                    color='orange'
                else:
                    color='yellow'
        
            elif pick:

                if [y,x] in available:
                    color='green'
                elif x==pickx and y==picky:
                    color='yellow'
                elif [y,x] in castling:
                    color='blue'
                elif [y,x] == passing:
                    color='blue'
                else:
                    color=table[n]
            else:
                color=table[n]
            
            pygame.draw.rect(screen, color, [x*width/8,y*height/8,(x+1)*width/8,(y+1)*height/8])
            n*=-1
            
            if board[y][x].type!='':
                display=pygame.transform.scale(pygame.image.load(board[y][x].image),(width/8,width/8))
                screen.blit(display, (x*width/8,y*height/8))

    if menu:
        draw_menu()



def get_threat(team):

    danger=[]
    for y in range(8):
        for x in range(8):
            if board[y][x].team==team:
                available=moves(y,x)
                danger+=available

    return danger
    

def verify_check():

    danger=[]
    for y in range(8):
        for x in range(8):
            if board[y][x].team==team:
                available=moves(y,x)
                danger+=available

    if [opp_kingy,opp_kingx] in danger:
        return True

    return False


def verify_checkmate():

    for move in moves(opp_kingy,opp_kingx):
        if move not in get_threat(team):
            return False

    for y in range(8):
        for x in range(8):
            danger=[]
            if board[y][x].team==opp and board[y][x].type!='king':

                
                for move in moves(y,x):
                    danger=[]
                    tryy,tryx=move[0],move[1]

                    ram.append(board[tryy][tryx])
                    board[tryy][tryx]=board[y][x]
                    board[y][x]=empty

                    nope=verify_check()

                    board[y][x]=board[tryy][tryx]
                    board[tryy][tryx]=ram.pop()

                    if nope:
                        continue

                    return False

    return True


def update_king():
   if board[newy][newx].type=='king':
       king_coords[board[newy][newx].team]=[newy,newx]

def get_mouse():
    mouse=pygame.mouse.get_pos()
    if menu or checkmate:
        return [-1000,-1000]
    return mouse
    
    
board_reset()





res=(800,800)
screen=pygame.display.set_mode(res)
see_through=pygame.Surface((800,800), pygame.SRCALPHA)
pygame.init()
pygame.font.init()
my_font=pygame.font.SysFont('Calibri', 100)
checkmate_mess=my_font.render('CHECKMATE',False,'red')
check_mess=my_font.render('CHECK',False,'blue')



if __name__ == "__main__":

    
    king_coords={'W': [7,4], 'B': [0,4]}
    
    menu=False
    available=[]
    checked=False
    check=False
    checkmate=False
    pick=False
    running=True
    castling=[]
    passing=[]
    en_passant_opportunity=False
    

    while running:
        
        team=table[turn]
        opp=table[turn*-1]
        kingy,kingx=king_coords[team][0],king_coords[team][1]
        opp_kingy,opp_kingx=king_coords[opp][0],king_coords[opp][1]

        print_board()
        if checkmate:
            screen.blit(checkmate_mess, (90,345))
        elif check:
            screen.blit(check_mess, (230,345))
        pygame.display.flip()
        
        if pick:
            if not checked:
                available=moves(y,x)

                cannot=[]
                for potential in available:
                    checky=potential[0]
                    checkx=potential[1]
                    #check if creates check for own team/doesnt break check
                    ram.append(board[checky][checkx])

                    board[checky][checkx]=board[y][x]
                    board[y][x]=empty
                    pygame.display.update()
                    danger=[]
                    for ay in range(8):
                        for ax in range(8):
                            if board[ay][ax].team==table[turn*-1]:
                                possible=moves(ay,ax)
                                danger+=possible
                            if board[ay][ax].type=='king':
                                if board[ay][ax].team==table[turn]:
                                    kingy=ay
                                    kingx=ax
                    print(danger)
                    
                    if [kingy,kingx] in danger:
                        
                        cannot.append(potential)
                    
                    board[y][x]=board[checky][checkx]
                    board[checky][checkx]=ram.pop()

                for possible in cannot:
                    available.remove(possible)
                
                checked=True

        for ev in pygame.event.get():

            if ev.type==pygame.QUIT:
                pygame.quit()
                running=False

            if ev.type==pygame.KEYDOWN:
                if ev.key==pygame.K_z and not pick:
                    if memory:
                        print('HEY')
                        board=memory.pop()
                        checkmate,check=False,False
                        turn*=-1
                    else:
                        print('ALREADY AT BEGGINING')
                        memory.append(copy.deepcopy(board))

                if ev.key==pygame.K_ESCAPE:
                    if menu:
                        menu=False
                    else:
                        menu=True

            if ev.type==pygame.MOUSEBUTTONDOWN and (not menu and not checkmate):
                mouse=get_mouse()
                
                if not pick:
                    y=mouse[1]//100
                    x=mouse[0]//100
                    pickx,picky=x,y

                    castling=check_castling()

                    

                    if en_passant_opportunity:
                        if board[picky][pickx].type=='pawn' and picky==epy and abs(pickx-epx)==1:
                            if board[picky][pickx].team=='B':
                                passing=[picky+1,epx]
                            if board[picky][pickx].team=='W':
                                passing=[picky-1,epx]
                
                    if board[y][x].team!=table[turn]:
                        print('Select a valid piece')
                        continue
                    pick=True
                    continue

                if mouse[1]//100==y and mouse[0]//100==x:
                    pick=False
                    checked=False
                    available=[]
                    passing=[]
                    continue
                
            
                
                    
                

                newy=mouse[1]//100
                newx=mouse[0]//100
                move=[newy,newx]    

                if move in castling:
                    if move[1]==7:
                        board[picky][7].virgin=False
                        board[picky][6]=board[picky][4]
                        king_coords[team]=[picky,6]
                        board[picky][5]=board[picky][7]
                        board[picky][7]=empty
                    if move[1]==0:
                        board[picky][0].virgin=False
                        board[picky][2]=board[picky][4]
                        king_coords[team]=[picky,2]
                        board[picky][3]=board[picky][0]
                        board[picky][0]=empty

                    board[picky][4].virgin=False
                    board[picky][4]=empty
                    
                    available=[]
                    pick=False
                    turn*=-1

                if move == passing:
                    board[newy][newx]=board[y][x]
                    board[y][x]=empty
                    board[y][newx]=empty
                    available=[]
                    pick=False
                    turn*=-1

                if move in available:

                    memory.append(copy.deepcopy(board))
                    
                   
                    board[newy][newx]=board[y][x]
                    board[y][x]=empty
                    
                    
                    board[newy][newx].virgin=False

                    update_king()

                    

                    pawn_to_queen()

                    danger=[]
                    if check:
                        check=False
                    
                    pick=False ####
                    

                    check=verify_check()        #CHECK
                        
                    checkmate=verify_checkmate()


                    #board=round_switch() ######
                    
                    en_passant_opportunity=False
                    en_passant_opportunity=check_en_passant()
                    if en_passant_opportunity:
                        epy=newy
                        epx=newx

                    
                    available=[]
                    turn*=-1
                    
                

                else:
                    print('Cannot move there')
                    
                checked=False
                castling=[]
                passing=[]
